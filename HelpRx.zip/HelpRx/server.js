var express=require("express");
var mysql=require("mysql2");
var fileuploader=require("express-fileupload");
const nodemailer=require("nodemailer");
var app=express();
app.listen(2011,function(){
    console.log("server started")
});

app.use(express.static("public"));
app.use(fileuploader());
app.use(express.urlencoded(true));
////////Database
var dbConfig={
    host:"127.0.0.1",
    user:"root",
   password:"Chirag155241",
   database:"usersignup",
    dateStrings:true
}
var dbCon=mysql.createConnection(dbConfig);
dbCon.connect(function(err){
    if(err==null){
        console.log("Connected Successfully")
    }
    else{
        resp.send(err);
    }
})


// app.post("/signup",function(req,resp){
//     //  resp.send("Data Reached");
    
//     var email=req.body.txtEmail;
//     var pwd=req.body.txtPwd;
//     var type1=req.body.selecttype;
   
// dbCon.query("insert into users(email,pwd,type1,dob,status) values(?,?,?,current_date(),1)",[email,pwd,type1],function(err){
//     if(err==null){
//        resp.send("Record saved successfully");
//     }
//     else{
//         resp.send(err);
//     }
// })
//  //resp.send("Welcome"+req.body.txtEmail +" "+"Pwd"+req.body.txtPwd);
// });
//////////Ajax
app.get("/chk-email",function(req,resp){
    dbCon.query("select * from users where email=?",[req.query.kuchemail],function(err,resultTable){
      if(err==null){
        if(resultTable.length==1){ 
            resp.send("Already Taken...")
        }
        else{
            resp.send("Available....");
        }
      }
      else{
        resp.send(err);
      }
    })
    
})
app.get("/chk-submit",function(req,resp){
       
    dbCon.query("insert into users(email,pwd,type1,dos,status) values(?,?,?,current_date(),1)",[req.query.kuchemail,req.query.kuchpwd,req.query.kuchtype],function(err){
      if(err==null){
        resp.send("Record Saved successfully");
        transporter.sendMail(options,function(err,info){
          if(err)
          {
            console.log(err);
            return;
          }
          console.log("sent: "+ info.response);
      
})
      }
      else{
        resp.send(err);
      }
    })
    

const transporter = nodemailer.createTransport({
  service:'gmail',
  auth: {
      user: 'chiraggupta1428@gmail.com',
      pass: 'kdleubudrtosalnw'
  }
});

const options = {
  from: "chiraggupta1428@gmail.com", // sender address
  to: req.query.kuchemail, // list of receivers
  subject: "Sign Up", // Subject line
  text: "You have successfully signed up", // plain text body
  html: "<b>You have successfully signed up</b>", // html body
};
});
app.get("/chk-login-submit",function(req,resp){
  dbCon.query("select * from users where email=? && pwd=?",[req.query.kuchemail,req.query.kuchpwd],function(err,resultJSONTable){
    if(err==null){
      if(resultJSONTable.length>0){
        if (resultJSONTable[0].status == 1) {
          resp.send(resultJSONTable[0].type1);
        } 
        else {
          resp.send("USER BLOCKED");
        }
      } 
      else {
        resp.send("INVALID EMAIL OR PASSWORD");
      }
    } 
    else {
      resp.send(err);
    }
  });
      
  })

///////DONOR PROFILE
app.get("/donar-profile",function(req,resp){
  resp.sendFile(process.cwd()+"/public/Profile-donar.html");
 //  location.href("profile.html"); only used in ajax
});
app.get("/get-profile-record",function(req,resp){
  dbCon.query("select * from donors where email=?",[req.query.kuchemail],function(err,resultJSONTable){
      if(err==null){
        resp.send(resultJSONTable);
      }
      else{
        resp.send(err);
      }
    })
});
// app.get("/chk-donor-profile-email",function(req,resp){
//   dbCon.query("select * from donors where email=?",[req.query.kuchEmail],function(err,resultTable){
//     if(err==null){
//       if(resultTable.length==1){
//           resp.send("Already Taken...")
//       }
//       else{
//           resp.send("Available....");
//       }
//     }
//     else{
//       resp.send(err);
//     }
//   })
  
// })
app.post("/donor-profile-submit",function(req,resp){
  //resp.send("Login reached");
  //resp.send(process.cwd()+"/public/uploads/"+fileName);
    var fileName="nopic.jpg";
    if(req.files!=null)
      {
        //console.log(process.cwd());
         fileName=req.files.ppic.name;
        var path=process.cwd()+"/public/uploads/"+fileName;
        req.files.ppic.mv(path);
      }
  var email=req.body.txtEmail;
  var name=req.body.txtname;
  var mobile=req.body.txtcontact;
  var address=req.body.txtaddress;
  var city=req.body.combocity;
  var id=req.body.idproof;
  var ahours=req.body.fromtime+"-"+req.body.totime;
  dbCon.query("insert into donors values(?,?,?,?,?,?,?,?)",[email,name,mobile,address,city,id,fileName,ahours],function(err){
    if(err==null){
        // resp.send("Record saved successfullyyyyyyy");
        resp.redirect("successful.html");
    }
    else{
        resp.send(err);
        //console.log(err);
    }
  })
})
app.post("/donor-profile-update",function(req,resp){
  //resp.send("Data Reached");
  var fileName;
  if(req.files!=null)
    {
      //console.log(process.cwd());
       fileName=req.files.ppic.name;
      var path=process.cwd()+"/public/uploads/"+fileName;
      req.files.ppic.mv(path);
    }
    else{
      fileName=req.body.hdn;
    }
    var email=req.body.txtEmail;
    var name=req.body.txtname;
    var mobile=req.body.txtcontact;
    var address=req.body.txtaddress;
    var city=req.body.combocity;
    var id=req.body.idproof;
    var ahours=req.body.fromtime+req.body.totime;
  dbCon.query("update  donors set name=?,mobile=?,address=?,city=?,proof=?,pic=?,ahours=? where email=?",[name,mobile,address,city,id,fileName,ahours,email],function(err,result){
  if(err==null){
     // resp.send(" Record Updated successfullyyyyyyy");
     resp.redirect("successful.html");
  }
  else{
      resp.send(err);
  }
  })
  //resp.send("Welcome"+req.body.txtEmail +" "+"Name"+req.body.txtname+" "+" Contact"+req.body.txtcontact+" "+"Adress"+req.body.txtaddress+"City"+city+"dob"+dob+"Gender"+gender+"Id"+id+"Pic"+fileName);
  });
///////DONOR AVAIL MED
app.get("/donar-avail-med",function(req,resp){
  resp.sendFile(process.cwd()+"/public/avail-med.html");
});
app.get("/avail-med-chk-submit",function(req,resp){
  dbCon.query("insert into medsavailable(email,medname,expdate,packing,qty) values(?,?,?,?,?)",[req.query.kuchemail,req.query.kuchmed,req.query.kuchdate,req.query.kuchpack,req.query.kuchqty],function(err){
    if(err==null){
      resp.send(" Availed Medicines successfully")
    }
    else{
      resp.send(err);
    }
  })
})
//////DONOR SETTINGS
app.get("/chk-set-update",function(req,resp){
  dbCon.query("update  users set pwd=? where email=? && pwd=?",[req.query.kuchnewpwd,req.query. kuchemail,req.query.kuchpwd],function(err,resultTable){
    if(err==null){
      resp.send("Password Updated");
      }
      
    else{
      resp.send(err);
    }
  });

});
///////NEEDY PROFILE
app.get("/needy-profile",function(req,resp){
  resp.sendFile(process.cwd()+"/public/Profile-needy.html");
})
///Submit for needy profile
app.post("/needy-profile-submit",function(req,resp){
  //resp.send("Login reached");
  //resp.send(process.cwd()+"/public/uploads/"+fileName);
    var fileName="nopic.jpg";
    if(req.files!=null)
      {
        //console.log(process.cwd());
         fileName=req.files.ppic.name;
        var path=process.cwd()+"/public/uploads/"+fileName;
        req.files.ppic.mv(path);
      }
  var email=req.body.txtEmail;
  var name=req.body.txtname;
  var mobile=req.body.txtcontact;
  var dob=req.body.dob;
  var gender=req.body.gender;
  var city=req.body.combocity;
  var address=req.body.txtaddress;
  dbCon.query("insert into  needy values(?,?,?,?,?,?,?,?)",[email,name,mobile,dob,gender,city,address,fileName],function(err){
    if(err==null){
        resp.send("Record saved successfullyyyyyyy");
    }
    else{
        resp.send(err);
        //console.log(err);
    }
  })
})
//search
app.get("/get-needy-profile-record",function(req,resp){
  dbCon.query("select * from needy where email=?",[req.query.kuchemail],function(err,resultJSONTable){
      if(err==null){
          // $("#needy-update").disabled==false;
        resp.send(resultJSONTable);

      }
      else{
        resp.send(err);
      }
    })
});
//update
app.post("/needy-profile-update",function(req,resp){
  //resp.send("Data Reached");
  var fileName;
  if(req.files!=null)
    {
      //console.log(process.cwd());
       fileName=req.files.ppic.name;
      var path=process.cwd()+"/public/uploads/"+fileName;
      req.files.ppic.mv(path);
    }
    else{
      fileName=req.body.hdn;
    }
    var email=req.body.txtEmail;
    var name=req.body.txtname;
   var mobile=req.body.txtcontact;
  var dob=req.body.dob;
  var gender=req.body.gender;
  var city=req.body.combocity;
  var address=req.body.txtaddress;
  dbCon.query("update  needy set name=?,mobile=?,dob=?,gender=?,city=?,address=?,pic=? where email=?",[name,mobile,dob,gender,city,address,fileName,email],function(err,result){
  if(err==null){
      resp.send(" Record Updated successfullyyyyyyy");
  }
  else{
      resp.send(err);
  }
  })
});
//NEEDY SETTINGS
app.get("/chk-set-needy-update",function(req,resp){
  dbCon.query("update  users set pwd=? where email=? && pwd=?",[req.query.kuchnewpwd,req.query. kuchemail,req.query.kuchpwd],function(err,resultTable){
    if(err==null){
      resp.send("Password Updated");
      }
      
    else{
      resp.send(err);
    }
  });

});
app.get("/angular",function(req,resp)
{
      resp.sendFile(process.cwd()+"/public/dash-admin.html");
})
////////////ADMIN SECTION
///FETCH DONOR
app.get("/fetch-donor-data",function(req,resp){
  // alert();
  resp.sendFile(process.cwd()+"/public/panel-donors.html");
});
app.get("/fetch-needy-data",function(req,resp){
  // alert();
  resp.sendFile(process.cwd()+"/public/panel-needy.html");
});
app.get("/fetch-donor-records",function(req,resp)
{
         //fixed                             //same seq. as in table
    dbCon.query("select * from donors",function(err,resultTableJSON)
    {
          if(err==null)
            resp.send(resultTableJSON);
              else
            resp.send(err);
    })
});
app.get("/fetch-needy-records",function(req,resp){
  dbCon.query("select * from needy",function(err,resultTableJSON)
  {
        if(err==null)
          resp.send(resultTableJSON);
            else
          resp.send(err);
  })
})
app.get("/fetch-all-data",function(req,resp){
  // alert();
  resp.sendFile(process.cwd()+"/public/panel-users.html");
});
/////ADMIN PANEL USERS
app.get("/fetch-users-records",function(req,resp){
  dbCon.query("select * from users",function(err,resultTableJSON)
  {
        if(err==null)
          resp.send(resultTableJSON);
            else
          resp.send(err);
  })
})
app.get("/do-angular-block",function(req,resp)
{
     //saving data in table
    var email=req.query.emailkuch;
    

         //fixed                             //same seq. as in table
    dbCon.query("update  users set status=0 where email=?",[email],function(err,result)
    {
          if(err==null)
          {
            if(result.affectedRows==1)
              resp.send("User Blocked");
          
            else
              resp.send("Inavlid Email id");
            }
              else
            resp.send(err);
    })
})
app.get("/do-angular-resume",function(req,resp)
{
     //saving data in table
    var email=req.query.emailkuch;
    

         //fixed                             //same seq. as in table
    dbCon.query("update  users set status=1 where email=?",[email],function(err,result)
    {
          if(err==null)
          {
            if(result.affectedRows==1)
              resp.send("User Resume");
          
            else
              resp.send("Inavlid Email id");
            }
              else
            resp.send(err);
    })
})
//////////////MEDICINE MANAGER
app.get("/donar-med-manager",function(req,resp){
 resp.sendFile(process.cwd()+"/public/med-manager.html");
});
app.get("/fetch-donor-med-details",function(req,resp){
  var email=req.query.emailkuch;
  dbCon.query("select * from medsavailable where email=?",[email],function(err,resultTableJSON)
  {
        if(err==null)
          resp.send(resultTableJSON);
            else
          resp.send(err);
  })
})
app.get("/do-delete-medmanage",function(req,resp){
  var sr=req.query.srnokuch;
  dbCon.query("delete from medsavailable where srno=?",[sr],function(err){
    if(err==null)
          {
            resp.send("Medicine deleted");
            }
              else
            resp.send(err);
  })
})
///////////FIND MEDICINE
app.get("/needy-find-med",function(req,resp){
  resp.sendFile(process.cwd()+"/public/finder-med.html");
})
////AT INDEX PAGE EXPIRED MEDICINE CHECKER
 app.get("/chk-exp",function(req,resp){

   dbCon.query("delete from medsavailable where expdate <= current_date()",function(err,result){
     if(err==null)
           {
            if(result.affectedRows>0){
             resp.send("Medicine deleted");
            }
            else{
              resp.send("No expired medicine yet");
            }
            }
      else{
      resp.send(err);
      }
   })
 })
////////////////// FINDEE CITIES
app.get("/get-cities",function(req,resp)
{
         //fixed                             //same seq. as in table
    dbCon.query("select distinct city from donors",function(err,resultTableJSON)
    {
          if(err==null)
            resp.send(resultTableJSON);
              else
            resp.send(err);
    })
});
///////////FINDER MEDICINES
app.get("/get-meds",function(req,resp)
{
         //fixed                             //same seq. as in table
    dbCon.query("select distinct medname from medsavailable",function(err,resultTableJSON)
    {
          if(err==null)
            resp.send(resultTableJSON);
              else
            resp.send(err);
})
})
////////FINDER MEDICINES
app.get("/fetch-donors",function(req,resp)
{
  console.log(req.query);
  var med=req.query.medKuch;
  var city=req.query.cityKuch;

  var query="select * from donors  inner join medsavailable on donors.email= medsavailable.email where medsavailable.medname=? and donors.city=?";
  

  dbCon.query(query,[med,city],function(err,resultTable)
  {
    console.log(resultTable+"      "+err);
  if(err==null)
    resp.send(resultTable);
  else
    resp.send(err);
})
})
